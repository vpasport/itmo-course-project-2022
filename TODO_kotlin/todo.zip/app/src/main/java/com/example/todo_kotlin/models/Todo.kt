package com.example.todo_kotlin.models

data class Todo(
    val text: String,
    val finished: Boolean,
    val id: Long
)