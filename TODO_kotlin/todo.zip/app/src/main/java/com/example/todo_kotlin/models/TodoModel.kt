package com.example.todo_kotlin.models

data class TodoModel(val todos: List<Todo>, val visibility: Visibility)